Arquivo zip gerado em: 21/12/2021 10:00:30 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Exercício 3] Busca Indexada em Lista Encadeada